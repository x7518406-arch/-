二十八星宿 MBTI 倾向测试（在线部署版）

部署：将本文件夹内的 index.html、config.js、config.json 和 images 文件夹整体上传到网页托管平台。

使用：打开网站网址即可测试。图片已转换为 WebP 以便手机快速加载；星宿图片映射已按成果图文件编号修正。
